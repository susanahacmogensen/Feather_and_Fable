# Author Website — Elegant + Whimsical

Edit `config.json`, then deploy on GitHub Pages or Netlify for free.
