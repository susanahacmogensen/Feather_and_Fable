See README for quick deploy steps.
